
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","BurzeDzisNet\\Alert"],["c","BurzeDzisNet\\BurzeDzisNet"],["c","BurzeDzisNet\\Endpoint"],["c","BurzeDzisNet\\EndpointInterface"],["c","BurzeDzisNet\\Point"],["c","BurzeDzisNet\\Storm"],["c","BurzeDzisNet\\WeatherAlert"]];
